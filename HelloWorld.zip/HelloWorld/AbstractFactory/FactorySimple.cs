﻿using HelloWorld.Builder;
using HelloWorld.Countries;
using HelloWorld.Decorator;

namespace HelloWorld.AbstractFactory {
    class FactorySimple : AbstractFactoryHelloWorld {
        public override ICountry makeFrance() {
            return new BuilderFrenchType1().getCountry();
        }

        public override ICountry makeIndonesia() {
            return new BuilderIndonesianType2().getCountry();
        }

        public override ICountry makeLatin() {
            return new LatinAdapted();
        }

        public override ICountry makeUnitedKingdom() {
            return new BuilderEnglishType1().getCountry();
        }

        public override ICountry makeUnitedStatesOfAmerica() {
            return new BuilderEnglishType2().getCountry();
        }
    }
}
