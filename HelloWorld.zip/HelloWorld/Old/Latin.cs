﻿namespace HelloWorld.Old {
    public class Latin {
        public string ave = "Ave";
    }
}
