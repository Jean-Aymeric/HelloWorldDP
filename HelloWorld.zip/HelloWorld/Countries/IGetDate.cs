﻿using System;

namespace HelloWorld {
    interface IGetDate {
        String getDate();
    }
}
