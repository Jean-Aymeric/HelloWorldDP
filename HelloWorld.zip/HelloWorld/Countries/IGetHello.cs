﻿using System;

namespace HelloWorld {
    interface IGetHello {
        String getHello();
    }
}
