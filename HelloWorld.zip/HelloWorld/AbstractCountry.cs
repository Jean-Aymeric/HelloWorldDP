﻿namespace HelloWorld {
    public abstract class AbstractCountry : ICountry {
        public abstract string getHelloMessage();
    }
}
