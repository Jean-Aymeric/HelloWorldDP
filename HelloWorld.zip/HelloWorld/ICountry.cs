﻿namespace HelloWorld {
    interface ICountry {
        string getHelloMessage();
    }
}
