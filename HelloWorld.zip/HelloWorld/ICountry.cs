﻿namespace HelloWorld {
    public interface ICountry {
        string getHelloMessage();
    }
}
