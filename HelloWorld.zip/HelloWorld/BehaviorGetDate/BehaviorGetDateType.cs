﻿namespace HelloWorld.BehaviorGetDate {
    public enum BehaviorGetDateType {
        Type1,
        Type2
    }
}
