﻿using System;

namespace HelloWorld.BehaviorGetDate {
    public interface IBehaviorGetDate {
        String getDate();
    }
}
