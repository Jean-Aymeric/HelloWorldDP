﻿namespace HelloWorld.BehaviorGetHello {
    class BehaviorGetIndonesianHello : IBehaviorGetHello {
        public string getHello() {
            return "Selamat pagi";
        }
    }
}

