﻿using System;

namespace HelloWorld.BehaviorGetHello {
    public interface IBehaviorGetHello {
        String getHello();
    }
}
