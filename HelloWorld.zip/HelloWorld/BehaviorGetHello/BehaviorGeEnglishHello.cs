﻿namespace HelloWorld.BehaviorGetHello {
    class BehaviorGeEnglishHello : IBehaviorGetHello {
        public string getHello() {
            return "Hello";
        }
    }
}
