﻿namespace HelloWorld.BehaviorGetHello {
    public enum BehaviorGetHelloType {
        English,
        French,
        Indonesian
    }
}
