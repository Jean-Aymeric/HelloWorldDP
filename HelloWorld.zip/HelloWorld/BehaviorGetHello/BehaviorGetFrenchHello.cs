﻿namespace HelloWorld.BehaviorGetHello {
    class BehaviorGetFrenchHello : IBehaviorGetHello {
        public string getHello() {
            return "Bonjour";
        }
    }
}

